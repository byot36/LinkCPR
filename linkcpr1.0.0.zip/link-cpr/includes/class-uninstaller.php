<?php
namespace LinkCPR;

class Uninstaller {

    public static function uninstall() {
        global $wpdb;

        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}link_cpr_links");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}link_cpr_logs");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}link_cpr_queue");

        delete_option('link_cpr_auto_scan');
        delete_option('link_cpr_enable_archive_fix');
        delete_option('link_cpr_enable_internal_fix');
        delete_option('link_cpr_enable_remove_fix');
        delete_option('link_cpr_email_reports');
        delete_option('link_cpr_report_email');
        delete_option('link_cpr_batch_size');
        delete_option('link_cpr_request_timeout');

        wp_clear_scheduled_hook('link_cpr_scheduled_scan');
        wp_clear_scheduled_hook('link_cpr_process_batch');
    }
}
