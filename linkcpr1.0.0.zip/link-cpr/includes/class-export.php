<?php
namespace LinkCPR;

class Export {

    public static function csv($links) {
        if (empty($links)) {
            wp_die(__('No data available for export.', 'link-cpr'));
        }

        $filename = 'link-cpr-export-' . wp_date('Y-m-d-H-i-s') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . esc_attr($filename) . '"');

        $output = fopen('php://output', 'w');

        fputcsv(
            $output,
            array(
                'ID',
                'Post ID',
                'URL',
                'Link Text',
                'Status Code',
                'Is Broken',
                'Archive URL',
                'Internal Suggestion',
                'Fixed',
                'Method',
                'Last Checked',
            )
        );

        foreach ($links as $link) {
            fputcsv(
                $output,
                array(
                    $link['id'],
                    $link['post_id'],
                    $link['url'],
                    $link['link_text'],
                    $link['status_code'],
                    $link['is_broken'] ? 'Yes' : 'No',
                    $link['archive_url'],
                    $link['internal_suggestion'],
                    $link['fixed'] ? 'Yes' : 'No',
                    $link['fix_method'],
                    $link['last_checked'],
                )
            );
        }

        fclose($output);
        exit;
    }
}
