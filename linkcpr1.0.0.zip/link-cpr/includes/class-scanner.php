<?php
namespace LinkCPR;

class Scanner {

    private $timeout;
    private $batch_size;
    private $rate_limit_delay;
    private $scan_images;
    private $exclude_patterns;

    public function __construct() {
        $this->timeout          = (int) get_option('link_cpr_request_timeout', 15);
        $this->batch_size       = (int) get_option('link_cpr_batch_size', 10);
        $this->rate_limit_delay = (float) get_option('link_cpr_rate_limit_delay', 0);
        $this->scan_images      = (bool) get_option('link_cpr_scan_images', 0);

        $raw = (string) get_option('link_cpr_exclude_urls', '');
        $this->exclude_patterns = array_filter(array_map('trim', explode("\n", $raw)));
    }

    private function is_excluded($url) {
        foreach ($this->exclude_patterns as $pattern) {
            if ($pattern !== '' && stripos($url, $pattern) !== false) {
                return true;
            }
        }
        return false;
    }

    public function scan_post($post_id) {
        $post = get_post($post_id);
        if (! $post || ! in_array($post->post_status, array('publish', 'private', 'draft'), true)) {
            return false;
        }

        $content = $post->post_content;
        if (empty($content)) {
            return false;
        }

        $links = $this->extract_links($content);
        if (empty($links)) {
            return false;
        }

        $results = array();

        foreach ($links as $link) {
            if ($this->is_excluded($link['url'])) {
                continue;
            }

            $check = $this->check_url($link['url']);

            $result = array(
                'post_id'       => $post_id,
                'post_type'     => $post->post_type,
                'link_type'     => $link['type'],
                'url'           => $link['url'],
                'link_text'     => $link['text'],
                'status_code'   => $check['code'],
                'is_broken'     => $check['broken'] ? 1 : 0,
                'is_redirect'   => $check['redirect'] ? 1 : 0,
                'broken_reason' => $check['reason'],
                'last_checked'  => current_time('mysql'),
            );

            if ($check['broken']) {
                $result['archive_url']        = Healer::get_archive_url($link['url']);
                $result['internal_suggestion'] = Healer::suggest_internal_link($link['text'], $post_id);
            }

            $this->save_link($result);
            $results[] = $result;

            Logger::debug(
                'Checked URL: ' . $link['url'] . ' Status: ' . $check['code'],
                array('post_id' => $post_id)
            );

            if ($this->rate_limit_delay > 0) {
                usleep((int) ($this->rate_limit_delay * 1000000));
            }
        }

        return $results;
    }

    private function extract_links($content) {
        $links = array();

        if (! class_exists('DOMDocument')) {
            Logger::error('DOMDocument not available. Cannot extract links.');
            return $links;
        }

        libxml_use_internal_errors(true);
        $dom = new \DOMDocument();

        $wrapped = '<?xml encoding="utf-8" ?>' . $content;
        @$dom->loadHTML($wrapped);
        libxml_clear_errors();

        $anchors = $dom->getElementsByTagName('a');

        foreach ($anchors as $anchor) {
            $href = $anchor->getAttribute('href');
            $text = trim($anchor->textContent);

            if (empty($href) || strpos($href, '#') === 0 || strpos($href, 'mailto:') === 0 || strpos($href, 'tel:') === 0 || strpos($href, 'javascript:') === 0) {
                continue;
            }

            if (strpos($href, 'http') !== 0) {
                $href = site_url($href);
            }

            $links[] = array(
                'url'  => esc_url_raw($href),
                'text' => sanitize_text_field($text),
                'type' => 'link',
            );
        }

        if ($this->scan_images) {
            $images = $dom->getElementsByTagName('img');

            foreach ($images as $img) {
                $src = $img->getAttribute('src');

                if (empty($src)) {
                    continue;
                }

                if (strpos($src, 'http') !== 0) {
                    $src = site_url($src);
                }

                $links[] = array(
                    'url'  => esc_url_raw($src),
                    'text' => sanitize_text_field($img->getAttribute('alt')),
                    'type' => 'image',
                );
            }
        }

        return $links;
    }

    public function check_url($url) {
        $response = wp_remote_head(
            $url,
            array(
                'timeout'     => $this->timeout,
                'sslverify'   => false,
                'user-agent'  => 'LinkCPR/1.0; WordPress Link Checker',
                'redirection' => 5,
            )
        );

        if (is_wp_error($response)) {
            $response_get = wp_remote_get(
                $url,
                array(
                    'timeout'     => $this->timeout,
                    'sslverify'   => false,
                    'user-agent'  => 'LinkCPR/1.0',
                    'redirection' => 5,
                )
            );

            if (is_wp_error($response_get)) {
                return array(
                    'code'     => 0,
                    'broken'   => true,
                    'redirect' => false,
                    'reason'   => $response->get_error_message(),
                );
            }

            $code = wp_remote_retrieve_response_code($response_get);
        } else {
            $code = wp_remote_retrieve_response_code($response);
        }

        $redirect = ($code >= 300 && $code < 400);
        $broken   = ($code >= 400 || $code === 0);
        $reason   = '';

        if ($code === 404) {
            $reason = 'Not Found';
        } elseif ($code >= 500) {
            $reason = 'Server Error';
        } elseif ($code === 0) {
            $reason = 'Connection Failed';
        } elseif ($code >= 400) {
            $reason = 'Client Error';
        } elseif ($redirect) {
            $reason = 'Redirect Loop or Unresolved Redirect';
        }

        return array(
            'code'     => $code,
            'broken'   => $broken,
            'redirect' => $redirect,
            'reason'   => $reason,
        );
    }

    private function save_link($data) {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_links';

        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM $table WHERE post_id = %d AND url = %s",
                $data['post_id'],
                $data['url']
            )
        );

        if ($existing) {
            $wpdb->update(
                $table,
                array(
                    'status_code'         => $data['status_code'],
                    'is_broken'           => $data['is_broken'],
                    'is_redirect'         => $data['is_redirect'],
                    'broken_reason'       => $data['broken_reason'],
                    'archive_url'         => $data['archive_url'] ?? null,
                    'internal_suggestion' => $data['internal_suggestion'] ?? null,
                    'last_checked'        => $data['last_checked'],
                ),
                array('id' => $existing),
                array('%s', '%d', '%d', '%s', '%s', '%s', '%s'),
                array('%d')
            );
        } else {
            $wpdb->insert($table, $data);
        }
    }

    public function queue_all_posts() {
        global $wpdb;
        $table_queue = $wpdb->prefix . 'link_cpr_queue';
        $wpdb->query("TRUNCATE TABLE $table_queue");

        $configured = get_option('link_cpr_post_types', array('post', 'page'));
        $post_types = apply_filters('link_cpr_post_types', $configured);

        $posts = get_posts(
            array(
                'post_type'      => $post_types,
                'post_status'    => array('publish', 'private'),
                'posts_per_page' => -1,
                'fields'         => 'ids',
            )
        );

        foreach ($posts as $post_id) {
            $wpdb->insert(
                $table_queue,
                array(
                    'post_id' => $post_id,
                    'status'  => 'pending',
                ),
                array('%d', '%s')
            );
        }

        Logger::info('Queued ' . count($posts) . ' posts for scanning.');
        return count($posts);
    }

    public function get_broken_links($limit = 50, $offset = 0, $filters = array()) {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_links';

        $where  = array('is_broken = 1', 'fixed = 0');
        $params = array();

        if (! empty($filters['post_type'])) {
            $where[]  = 'post_type = %s';
            $params[] = sanitize_text_field($filters['post_type']);
        }

        if (! empty($filters['status_code'])) {
            $where[]  = 'status_code = %s';
            $params[] = sanitize_text_field($filters['status_code']);
        }

        if (! empty($filters['date_from'])) {
            $where[]  = 'created_at >= %s';
            $params[] = sanitize_text_field($filters['date_from']) . ' 00:00:00';
        }

        if (! empty($filters['date_to'])) {
            $where[]  = 'created_at <= %s';
            $params[] = sanitize_text_field($filters['date_to']) . ' 23:59:59';
        }

        $where_sql = implode(' AND ', $where);

        $total = (int) $wpdb->get_var(
            $params
                ? $wpdb->prepare("SELECT COUNT(*) FROM $table WHERE $where_sql", $params)
                : "SELECT COUNT(*) FROM $table WHERE $where_sql"
        );

        $query_params   = $params;
        $query_params[] = $limit;
        $query_params[] = $offset;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table WHERE $where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d",
                $query_params
            ),
            ARRAY_A
        );

        return array(
            'items' => $rows,
            'total' => $total,
        );
    }

    public function get_queue_progress() {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_queue';

        $total     = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
        $completed = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'completed'");

        return array(
            'total'     => $total,
            'completed' => $completed,
        );
    }
}
