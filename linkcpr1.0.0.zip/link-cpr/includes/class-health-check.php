<?php
namespace LinkCPR;

class HealthCheck {

    public static function run() {
        $issues = array();

        if (!class_exists('DOMDocument')) {
            $issues[] = __('DOMDocument extension is missing. Link extraction will not function.', 'link-cpr');
        }

        if (!function_exists('curl_init') && !function_exists('wp_remote_get')) {
            $issues[] = __('Neither cURL nor WordPress HTTP API is available.', 'link-cpr');
        }

        $max_execution = (int) ini_get('max_execution_time');
        if ($max_execution !== 0 && $max_execution < 30) {
            $issues[] = sprintf(__('max_execution_time is low (%ds). Scans may timeout.', 'link-cpr'), $max_execution);
        }

        return $issues;
    }
}
