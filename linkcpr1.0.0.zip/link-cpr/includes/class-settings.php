<?php
namespace LinkCPR;

class Settings {

    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function register_settings() {
        register_setting('link_cpr_settings_group', 'link_cpr_auto_scan', 'sanitize_text_field');
        register_setting('link_cpr_settings_group', 'link_cpr_enable_archive_fix', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_enable_internal_fix', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_enable_remove_fix', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_email_reports', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_report_email', 'sanitize_email');
        register_setting('link_cpr_settings_group', 'link_cpr_batch_size', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_request_timeout', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_post_types', array($this, 'sanitize_post_types'));
        register_setting('link_cpr_settings_group', 'link_cpr_scan_images', 'intval');
        register_setting('link_cpr_settings_group', 'link_cpr_exclude_urls', 'sanitize_textarea_field');
        register_setting('link_cpr_settings_group', 'link_cpr_rate_limit_delay', 'floatval');
        register_setting('link_cpr_settings_group', 'link_cpr_slack_webhook', 'sanitize_text_field');

        add_settings_section('link_cpr_main', __('General Settings', 'link-cpr'), array($this, 'section_main'), 'link-cpr-settings');
        add_settings_section('link_cpr_auto_fix', __('Auto-Fix Rules (Pro)', 'link-cpr'), array($this, 'section_auto_fix'), 'link-cpr-settings');
        add_settings_section('link_cpr_notifications', __('Notifications', 'link-cpr'), array($this, 'section_notifications'), 'link-cpr-settings');
        add_settings_section('link_cpr_advanced', __('Advanced', 'link-cpr'), array($this, 'section_advanced'), 'link-cpr-settings');

        add_settings_field('auto_scan', __('Scan Frequency', 'link-cpr'), array($this, 'field_auto_scan'), 'link-cpr-settings', 'link_cpr_main');
        add_settings_field('post_types', __('Post Types to Scan', 'link-cpr'), array($this, 'field_post_types'), 'link-cpr-settings', 'link_cpr_main');
        add_settings_field('scan_images', __('Scan Images', 'link-cpr'), array($this, 'field_checkbox'), 'link-cpr-settings', 'link_cpr_main', array('key' => 'link_cpr_scan_images', 'desc' => __('Also check <img> src attributes for broken images.', 'link-cpr')));
        add_settings_field('exclude_urls', __('Exclude URL Patterns', 'link-cpr'), array($this, 'field_exclude_urls'), 'link-cpr-settings', 'link_cpr_main');
        add_settings_field('enable_archive', __('Enable Archive.org Fix', 'link-cpr'), array($this, 'field_checkbox'), 'link-cpr-settings', 'link_cpr_auto_fix', array('key' => 'link_cpr_enable_archive_fix', 'desc' => __('Attempt to replace broken links with Wayback Machine snapshots.', 'link-cpr')));
        add_settings_field('enable_internal', __('Enable Internal Linking', 'link-cpr'), array($this, 'field_checkbox'), 'link-cpr-settings', 'link_cpr_auto_fix', array('key' => 'link_cpr_enable_internal_fix', 'desc' => __('Suggest relevant internal posts as replacements.', 'link-cpr')));
        add_settings_field('enable_remove', __('Enable Remove Fallback', 'link-cpr'), array($this, 'field_checkbox'), 'link-cpr-settings', 'link_cpr_auto_fix', array('key' => 'link_cpr_enable_remove_fix', 'desc' => __('If no replacement found, strip the link and keep text.', 'link-cpr')));
        add_settings_field('email_reports', __('Email Reports', 'link-cpr'), array($this, 'field_checkbox'), 'link-cpr-settings', 'link_cpr_notifications', array('key' => 'link_cpr_email_reports', 'desc' => __('Receive daily summary emails.', 'link-cpr')));
        add_settings_field('report_email', __('Report Email Address', 'link-cpr'), array($this, 'field_email'), 'link-cpr-settings', 'link_cpr_notifications');
        add_settings_field('slack_webhook', __('Slack Webhook URL', 'link-cpr'), array($this, 'field_slack_webhook'), 'link-cpr-settings', 'link_cpr_notifications');
        add_settings_field('batch_size', __('Batch Size', 'link-cpr'), array($this, 'field_number'), 'link-cpr-settings', 'link_cpr_advanced');
        add_settings_field('timeout', __('Request Timeout', 'link-cpr'), array($this, 'field_number'), 'link-cpr-settings', 'link_cpr_advanced', array('key' => 'link_cpr_request_timeout', 'desc' => __('Seconds to wait for remote server response.', 'link-cpr')));
        add_settings_field('rate_limit_delay', __('Rate Limit Delay (seconds)', 'link-cpr'), array($this, 'field_number'), 'link-cpr-settings', 'link_cpr_advanced', array('key' => 'link_cpr_rate_limit_delay', 'desc' => __('Delay between each link check to avoid hammering remote servers.', 'link-cpr')));
    }

    public function sanitize_post_types($value) {
        if (! is_array($value)) {
            return array('post', 'page');
        }
        return array_map('sanitize_key', $value);
    }

    public function section_main() {
        echo '<p>' . __('Configure how Link CPR behaves on your site.', 'link-cpr') . '</p>';
    }

    public function section_auto_fix() {
        echo '<p>' . __('Pro features for automatic healing of broken links.', 'link-cpr') . '</p>';
    }

    public function section_notifications() {
        echo '<p>' . __('Stay informed about broken links via email.', 'link-cpr') . '</p>';
    }

    public function section_advanced() {
        echo '<p>' . __('Fine-tune performance and server limits.', 'link-cpr') . '</p>';
    }

    public function field_auto_scan() {
        $val = get_option('link_cpr_auto_scan', 'weekly');
        ?>
        <select name="link_cpr_auto_scan">
            <option value="disabled" <?php selected($val, 'disabled'); ?>><?php _e('Disabled', 'link-cpr'); ?></option>
            <option value="hourly" <?php selected($val, 'hourly'); ?>><?php _e('Hourly', 'link-cpr'); ?></option>
            <option value="twicedaily" <?php selected($val, 'twicedaily'); ?>><?php _e('Twice Daily', 'link-cpr'); ?></option>
            <option value="daily" <?php selected($val, 'daily'); ?>><?php _e('Daily', 'link-cpr'); ?></option>
            <option value="weekly" <?php selected($val, 'weekly'); ?>><?php _e('Weekly', 'link-cpr'); ?></option>
        </select>
        <?php
    }

    public function field_checkbox($args) {
        $key = $args['key'];
        $val = get_option($key, 0);
        ?>
        <label>
            <input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(1, $val); ?> />
            <?php echo esc_html($args['desc']); ?>
        </label>
        <?php
    }

    public function field_post_types() {
        $selected   = (array) get_option('link_cpr_post_types', array('post', 'page'));
        $post_types = get_post_types(array('public' => true), 'objects');

        foreach ($post_types as $post_type) {
            ?>
            <label style="display:block; margin-bottom:6px;">
                <input type="checkbox" name="link_cpr_post_types[]" value="<?php echo esc_attr($post_type->name); ?>" <?php checked(in_array($post_type->name, $selected, true)); ?> />
                <?php echo esc_html($post_type->labels->singular_name); ?>
            </label>
            <?php
        }
    }

    public function field_exclude_urls() {
        $val = get_option('link_cpr_exclude_urls', '');
        ?>
        <textarea name="link_cpr_exclude_urls" rows="4" class="large-text" placeholder="<?php esc_attr_e("e.g. example.com/ignore\nanother-domain.com", 'link-cpr'); ?>"><?php echo esc_textarea($val); ?></textarea>
        <p class="description"><?php _e('One URL pattern per line. Any link containing these will be skipped during scans.', 'link-cpr'); ?></p>
        <?php
    }

    public function field_slack_webhook() {
        $val = get_option('link_cpr_slack_webhook', '');
        echo '<input type="text" name="link_cpr_slack_webhook" value="' . esc_attr($val) . '" class="regular-text" placeholder="https://hooks.slack.com/services/..." />';
        echo '<p class="description">' . __('Optional. Sends a scan summary to this Slack incoming webhook.', 'link-cpr') . '</p>';
    }

    public function field_email() {
        $val = get_option('link_cpr_report_email', get_option('admin_email'));
        echo '<input type="email" name="link_cpr_report_email" value="' . esc_attr($val) . '" class="regular-text" />';
    }

    public function field_number($args) {
        $key  = isset($args['key']) ? $args['key'] : 'link_cpr_batch_size';
        $val  = get_option($key, ($key === 'link_cpr_batch_size') ? 10 : 15);
        $desc = isset($args['desc']) ? $args['desc'] : '';
        echo '<input type="number" name="' . esc_attr($key) . '" value="' . esc_attr($val) . '" class="small-text" />';
        if ($desc) {
            echo '<p class="description">' . esc_html($desc) . '</p>';
        }
    }
}
