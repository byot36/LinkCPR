<?php
namespace LinkCPR;

class Admin {

    public function init() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('wp_ajax_link_cpr_start_scan', array($this, 'ajax_start_scan'));
        add_action('wp_ajax_link_cpr_fix_link', array($this, 'ajax_fix_link'));
        add_action('wp_ajax_link_cpr_bulk_fix', array($this, 'ajax_bulk_fix'));
        add_action('wp_ajax_link_cpr_undo_fix', array($this, 'ajax_undo_fix'));
        add_action('wp_ajax_link_cpr_get_stats', array($this, 'ajax_get_stats'));
        add_action('wp_ajax_link_cpr_get_broken_links', array($this, 'ajax_get_broken_links'));
        add_action('wp_ajax_link_cpr_scan_progress', array($this, 'ajax_scan_progress'));
        add_action('wp_ajax_link_cpr_export_csv', array($this, 'ajax_export_csv'));
        add_filter('cron_schedules', array($this, 'add_cron_intervals'));
    }

    public function add_cron_intervals($schedules) {
        $schedules['weekly'] = array(
            'interval' => 7 * DAY_IN_SECONDS,
            'display'  => __('Once Weekly', 'link-cpr'),
        );
        return $schedules;
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Link CPR', 'link-cpr'),
            __('Link CPR', 'link-cpr'),
            'manage_options',
            'link-cpr',
            array($this, 'render_dashboard'),
            'dashicons-editor-unlink',
            80
        );

        add_submenu_page('link-cpr', __('Dashboard', 'link-cpr'), __('Dashboard', 'link-cpr'), 'manage_options', 'link-cpr', array($this, 'render_dashboard'));
        add_submenu_page('link-cpr', __('Scan Results', 'link-cpr'), __('Scan Results', 'link-cpr'), 'manage_options', 'link-cpr-results', array($this, 'render_results'));
        add_submenu_page('link-cpr', __('Settings', 'link-cpr'), __('Settings', 'link-cpr'), 'manage_options', 'link-cpr-settings', array($this, 'render_settings'));
        add_submenu_page('link-cpr', __('Reports', 'link-cpr'), __('Reports', 'link-cpr'), 'manage_options', 'link-cpr-reports', array($this, 'render_reports'));
    }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'link-cpr') === false) {
            return;
        }

        wp_enqueue_style('link-cpr-admin', LINK_CPR_PLUGIN_URL . 'assets/css/admin.css', array(), LINK_CPR_VERSION);

        $script_deps = array('jquery');

        if (strpos($hook, 'link-cpr-reports') !== false) {
            wp_enqueue_script('link-cpr-chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', array(), '4.4.0', true);
            $script_deps[] = 'link-cpr-chartjs';
        }

        wp_enqueue_script('link-cpr-admin', LINK_CPR_PLUGIN_URL . 'assets/js/admin.js', $script_deps, LINK_CPR_VERSION, true);

        wp_localize_script(
            'link-cpr-admin',
            'linkCPR',
            array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('link_cpr_nonce'),
                'strings' => array(
                    'fixConfirm'  => __('Are you sure you want to fix this link?', 'link-cpr'),
                    'scanStarted' => __('Scan started successfully!', 'link-cpr'),
                    'error'       => __('An error occurred.', 'link-cpr'),
                ),
            )
        );
    }

    public function render_dashboard() {
        include LINK_CPR_PLUGIN_DIR . 'templates/dashboard.php';
    }

    public function render_results() {
        include LINK_CPR_PLUGIN_DIR . 'templates/scan-results.php';
    }

    public function render_settings() {
        include LINK_CPR_PLUGIN_DIR . 'templates/settings-page.php';
    }

    public function render_reports() {
        include LINK_CPR_PLUGIN_DIR . 'templates/reports-page.php';
    }

    public function ajax_start_scan() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }

        $scanner = new Scanner();
        $count   = $scanner->queue_all_posts();

        wp_send_json_success(array('message' => sprintf(__('%d posts queued for scanning.', 'link-cpr'), $count)));
    }

    public function ajax_fix_link() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }

        $id         = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;
        $method     = isset($_POST['method']) ? sanitize_text_field($_POST['method']) : 'archive';
        $manual_url = isset($_POST['manual_url']) ? esc_url_raw($_POST['manual_url']) : '';

        if (! $id) {
            wp_send_json_error(__('Invalid link ID.', 'link-cpr'));
        }

        $result = Healer::fix_link($id, $method, $manual_url);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_bulk_fix() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }

        $ids    = isset($_POST['link_ids']) ? array_map('intval', (array) $_POST['link_ids']) : array();
        $method = isset($_POST['method']) ? sanitize_text_field($_POST['method']) : 'archive';

        if (empty($ids)) {
            wp_send_json_error(__('No links selected.', 'link-cpr'));
        }

        $fixed = 0;
        foreach ($ids as $id) {
            $result = Healer::fix_link($id, $method);
            if ($result['success']) {
                $fixed++;
            }
        }

        wp_send_json_success(array('message' => sprintf(__('%d of %d links fixed.', 'link-cpr'), $fixed, count($ids))));
    }

    public function ajax_undo_fix() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }

        $id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;
        if (! $id) {
            wp_send_json_error(__('Invalid link ID.', 'link-cpr'));
        }

        $result = Healer::undo_fix($id);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }

    public function ajax_get_stats() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }
        wp_send_json_success(Database::get_stats());
    }

    public function ajax_get_broken_links() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }

        $page     = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
        $per_page = 20;
        $offset   = ($page - 1) * $per_page;

        $filters = array(
            'post_type'   => isset($_POST['post_type']) ? sanitize_text_field($_POST['post_type']) : '',
            'status_code' => isset($_POST['status_code']) ? sanitize_text_field($_POST['status_code']) : '',
            'date_from'   => isset($_POST['date_from']) ? sanitize_text_field($_POST['date_from']) : '',
            'date_to'     => isset($_POST['date_to']) ? sanitize_text_field($_POST['date_to']) : '',
        );

        $scanner = new Scanner();
        wp_send_json_success($scanner->get_broken_links($per_page, $offset, $filters));
    }

    public function ajax_scan_progress() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied.', 'link-cpr'));
        }

        $scanner = new Scanner();
        wp_send_json_success($scanner->get_queue_progress());
    }

    public function ajax_export_csv() {
        check_ajax_referer('link_cpr_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'link-cpr'));
        }

        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_links';
        $links = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC", ARRAY_A);

        Export::csv($links);
    }
}
