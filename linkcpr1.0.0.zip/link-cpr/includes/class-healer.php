<?php
namespace LinkCPR;

class Healer {

    public static function get_archive_url($url) {
        $cache_key = 'link_cpr_archive_' . md5($url);
        $cached    = get_transient($cache_key);

        if (false !== $cached) {
            return ($cached === 'none') ? false : $cached;
        }

        $cdx_url = 'https://web.archive.org/cdx/search/cdx?url=' . urlencode($url)
            . '&output=json&fl=timestamp,original&filter=statuscode:200&collapse=digest&limit=1';

        $response = wp_remote_get($cdx_url, array('timeout' => 10));

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (! empty($data) && is_array($data) && count($data) > 1) {
            $row = isset($data[1]) ? $data[1] : $data[0];
            if (is_array($row) && count($row) >= 2) {
                $timestamp    = sanitize_text_field($row[0]);
                $original     = esc_url_raw($row[1]);
                $archive_url  = 'https://web.archive.org/web/' . $timestamp . '/' . $original;
                set_transient($cache_key, $archive_url, WEEK_IN_SECONDS);
                return $archive_url;
            }
        }

        set_transient($cache_key, 'none', WEEK_IN_SECONDS);
        return false;
    }

    public static function suggest_internal_link($anchor_text, $exclude_post_id) {
        if (empty($anchor_text)) {
            return false;
        }

        $words = explode(' ', sanitize_text_field($anchor_text));
        if (count($words) > 5) {
            $words = array_slice($words, 0, 5);
        }
        $search_term = implode(' ', $words);

        $query = new \WP_Query(
            array(
                'post_type'    => 'any',
                'post_status'  => 'publish',
                'posts_per_page' => 1,
                'post__not_in' => array($exclude_post_id),
                's'            => $search_term,
                'fields'       => 'ids',
            )
        );

        if ($query->have_posts()) {
            return get_permalink($query->posts[0]);
        }

        if (count($words) === 1) {
            $slug_query = new \WP_Query(
                array(
                    'post_type'    => 'any',
                    'post_status'  => 'publish',
                    'posts_per_page' => 1,
                    'post__not_in' => array($exclude_post_id),
                    'name__like'   => sanitize_title($words[0]),
                    'fields'       => 'ids',
                )
            );
            if ($slug_query->have_posts()) {
                return get_permalink($slug_query->posts[0]);
            }
        }

        return false;
    }

    public static function fix_link($link_id, $method = 'archive', $manual_url = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_links';
        $link  = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table WHERE id = %d", $link_id),
            ARRAY_A
        );

        if (! $link || ! $link['is_broken']) {
            return array('success' => false, 'message' => __('Link not found or not broken.', 'link-cpr'));
        }

        $post_id = (int) $link['post_id'];
        $old_url = $link['url'];
        $new_url = false;

        if ($method === 'archive') {
            $new_url = ! empty($link['archive_url']) ? $link['archive_url'] : self::get_archive_url($old_url);
        } elseif ($method === 'internal') {
            $new_url = ! empty($link['internal_suggestion']) ? $link['internal_suggestion'] : self::suggest_internal_link($link['link_text'], $post_id);
        } elseif ($method === 'manual') {
            $new_url = esc_url_raw($manual_url);
        } elseif ($method === 'remove') {
            $new_url = 'remove';
        }

        if (! $new_url && $method !== 'remove') {
            return array('success' => false, 'message' => __('No replacement URL found.', 'link-cpr'));
        }

        $update_result = self::update_post_content($post_id, $old_url, $new_url, $link['link_text']);
        if (! $update_result) {
            return array('success' => false, 'message' => __('Failed to update post content.', 'link-cpr'));
        }

        $wpdb->update(
            $table,
            array(
                'fixed'        => 1,
                'fix_method'   => $method,
                'fix_date'     => current_time('mysql'),
                'previous_url' => $old_url,
            ),
            array('id' => $link_id),
            array('%d', '%s', '%s', '%s'),
            array('%d')
        );

        Logger::info(
            "Link fixed via {$method}",
            array(
                'post_id' => $post_id,
                'old_url' => $old_url,
                'new_url' => ($new_url === 'remove') ? 'REMOVED' : $new_url,
            )
        );

        return array(
            'success'  => true,
            'message'  => __('Link fixed successfully.', 'link-cpr'),
            'new_url'  => $new_url,
        );
    }

    public static function undo_fix($link_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_links';
        $link  = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table WHERE id = %d", $link_id),
            ARRAY_A
        );

        if (! $link || ! $link['fixed'] || empty($link['previous_url'])) {
            return array('success' => false, 'message' => __('Nothing to undo for this link.', 'link-cpr'));
        }

        $post_id       = (int) $link['post_id'];
        $current_url   = $link['url'];
        $previous_url  = $link['previous_url'];

        $post = get_post($post_id);
        if (! $post) {
            return array('success' => false, 'message' => __('Post no longer exists.', 'link-cpr'));
        }

        $content = str_replace($current_url, esc_url($previous_url), $post->post_content);
        $result  = wp_update_post(array('ID' => $post_id, 'post_content' => $content), true);

        if (is_wp_error($result)) {
            return array('success' => false, 'message' => __('Failed to restore post content.', 'link-cpr'));
        }

        $wpdb->update(
            $table,
            array(
                'fixed'        => 0,
                'fix_method'   => null,
                'fix_date'     => null,
                'previous_url' => null,
            ),
            array('id' => $link_id),
            array('%d', '%s', '%s', '%s'),
            array('%d')
        );

        Logger::info('Fix undone', array('post_id' => $post_id, 'restored_url' => $previous_url));

        return array('success' => true, 'message' => __('Fix undone successfully.', 'link-cpr'));
    }

    private static function update_post_content($post_id, $old_url, $new_url, $link_text) {
        $post = get_post($post_id);
        if (! $post) {
            return false;
        }

        $content = $post->post_content;

        if ($new_url === 'remove') {
            if (class_exists('DOMDocument')) {
                libxml_use_internal_errors(true);
                $dom = new \DOMDocument();
                $wrapped = '<?xml encoding="utf-8" ?>' . $content;
                @$dom->loadHTML($wrapped);
                $anchors = $dom->getElementsByTagName('a');
                $to_remove = array();

                foreach ($anchors as $anchor) {
                    if ($anchor->getAttribute('href') === $old_url) {
                        $to_remove[] = $anchor;
                    }
                }

                foreach ($to_remove as $anchor) {
                    $textNode = $dom->createTextNode($anchor->textContent);
                    $anchor->parentNode->insertBefore($textNode, $anchor);
                    $anchor->parentNode->removeChild($anchor);
                }

                $content = $dom->saveHTML();
                libxml_clear_errors();

                $content = preg_replace('/^<\?xml encoding="utf-8" \?>/', '', $content);
                $content = preg_replace('/<!DOCTYPE.*?>/', '', $content);
                $content = preg_replace('/<html><body>/', '', $content);
                $content = preg_replace('/<\/body><\/html>/', '', $content);
            } else {
                $pattern = '/<a[^>]+href=["\']' . preg_quote(esc_url($old_url), '/') . '["\'][^>]*>(.*?)<\/a>/i';
                $content = preg_replace($pattern, '$1', $content, 1);
            }
        } else {
            $content = str_replace($old_url, esc_url($new_url), $content);
        }

        $result = wp_update_post(
            array(
                'ID'           => $post_id,
                'post_content' => $content,
            ),
            true
        );

        return ! is_wp_error($result);
    }
}
