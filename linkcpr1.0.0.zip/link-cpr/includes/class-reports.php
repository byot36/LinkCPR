<?php
namespace LinkCPR;

class Reports {

    public function send_email_report() {
        $stats = Database::get_stats();
        $email = get_option('link_cpr_report_email', get_option('admin_email'));
        $subject = sprintf('[%s] Link CPR Daily Report - %s', get_bloginfo('name'), wp_date('Y-m-d'));

        $message  = '<h2>' . __('Link CPR Daily Report', 'link-cpr') . "</h2>\n";
        $message .= "<table border='1' cellpadding='8' cellspacing='0' style='border-collapse:collapse;font-family:sans-serif;'>";
        $message .= "<tr style='background:#f0f0f0;'><td>" . __('Total Links Checked', 'link-cpr') . '</td><td>' . intval($stats['total']) . "</td></tr>\n";
        $message .= '<tr><td>' . __('Broken Found', 'link-cpr') . '</td><td>' . intval($stats['broken']) . "</td></tr>\n";
        $message .= '<tr><td>' . __('Fixed', 'link-cpr') . '</td><td>' . intval($stats['fixed']) . "</td></tr>\n";
        $message .= '<tr><td>' . __('Pending Fixes', 'link-cpr') . '</td><td>' . intval($stats['pending']) . "</td></tr>\n";
        $message .= "</table>\n";
        $message .= '<p>' . __('View full dashboard:', 'link-cpr') . ' <a href="' . esc_url(admin_url('admin.php?page=link-cpr')) . '">Link CPR Dashboard</a></p>';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($email, $subject, $message, $headers);

        Logger::info('Daily email report sent.', array('recipient' => $email));
    }

    public function send_slack_notification() {
        $webhook = get_option('link_cpr_slack_webhook', '');
        if (empty($webhook)) {
            return;
        }

        $stats = Database::get_stats();
        $text  = sprintf(
            "*Link CPR Scan Complete* on %s\n• Total checked: %d\n• Broken found: %d\n• Fixed: %d\n• Pending: %d",
            get_bloginfo('name'),
            $stats['total'],
            $stats['broken'],
            $stats['fixed'],
            $stats['pending']
        );

        wp_remote_post(
            $webhook,
            array(
                'timeout' => 10,
                'headers' => array('Content-Type' => 'application/json'),
                'body'    => wp_json_encode(array('text' => $text)),
            )
        );
    }

    public function generate_chart_data($days = 7) {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_logs';
        $data  = array();

        for ($i = $days - 1; $i >= 0; $i--) {
            $date  = date('Y-m-d', strtotime("-$i days"));
            $count = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM $table WHERE DATE(created_at) = %s AND action IN ('Link Fixed', 'Auto Fixed')",
                    $date
                )
            );
            $data[] = array(
                'date'  => $date,
                'count' => $count,
            );
        }

        return $data;
    }
}
