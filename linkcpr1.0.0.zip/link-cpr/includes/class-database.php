<?php
namespace LinkCPR;

class Database {

    const DB_VERSION = '1.1.0';

    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_links = $wpdb->prefix . 'link_cpr_links';
        $table_logs  = $wpdb->prefix . 'link_cpr_logs';
        $table_queue = $wpdb->prefix . 'link_cpr_queue';

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $sql_links = "CREATE TABLE IF NOT EXISTS $table_links (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            post_type varchar(50) NOT NULL DEFAULT 'post',
            link_type varchar(10) NOT NULL DEFAULT 'link',
            url text NOT NULL,
            link_text text DEFAULT NULL,
            status_code varchar(10) DEFAULT NULL,
            is_broken tinyint(1) DEFAULT 0,
            is_redirect tinyint(1) DEFAULT 0,
            broken_reason varchar(255) DEFAULT NULL,
            archive_url text DEFAULT NULL,
            internal_suggestion text DEFAULT NULL,
            fixed tinyint(1) DEFAULT 0,
            fix_method varchar(50) DEFAULT NULL,
            fix_date datetime DEFAULT NULL,
            previous_url text DEFAULT NULL,
            last_checked datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY status_code (status_code),
            KEY is_broken (is_broken),
            KEY fixed (fixed)
        ) $charset_collate;";

        $sql_logs = "CREATE TABLE IF NOT EXISTS $table_logs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            action varchar(100) NOT NULL,
            details longtext DEFAULT NULL,
            affected_rows int(11) DEFAULT 0,
            performed_by bigint(20) unsigned DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY action (action),
            KEY created_at (created_at)
        ) $charset_collate;";

        $sql_queue = "CREATE TABLE IF NOT EXISTS $table_queue (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            status varchar(50) DEFAULT 'pending',
            processed_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_id (post_id),
            KEY status (status)
        ) $charset_collate;";

        dbDelta($sql_links);
        dbDelta($sql_logs);
        dbDelta($sql_queue);

        update_option('link_cpr_db_version', self::DB_VERSION);
    }

    public static function maybe_upgrade() {
        if (get_option('link_cpr_db_version') !== self::DB_VERSION) {
            self::create_tables();
        }
    }

    public static function get_stats() {
        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_links';
        return array(
            'total'    => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table"),
            'broken'   => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_broken = 1"),
            'fixed'    => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE fixed = 1"),
            'pending'  => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_broken = 1 AND fixed = 0"),
            'redirect' => (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_redirect = 1"),
        );
    }
}
