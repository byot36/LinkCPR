<?php
namespace LinkCPR;

class Deactivator {

    public static function deactivate() {
        wp_clear_scheduled_hook('link_cpr_scheduled_scan');
        wp_clear_scheduled_hook('link_cpr_process_batch');
        Logger::info('Link CPR deactivated. Cron jobs cleared.');
    }
}
