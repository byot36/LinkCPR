<?php
namespace LinkCPR;

class Logger {

    const LEVEL_INFO    = 'info';
    const LEVEL_WARNING = 'warning';
    const LEVEL_ERROR   = 'error';
    const LEVEL_DEBUG   = 'debug';

    public static function log($message, $level = self::LEVEL_INFO, $context = array()) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[LinkCPR][' . strtoupper($level) . '] ' . $message);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'link_cpr_logs';

        $wpdb->insert(
            $table,
            array(
                'action'       => sanitize_text_field($level),
                'details'      => sanitize_textarea_field($message . ' | Context: ' . wp_json_encode($context)),
                'performed_by' => get_current_user_id(),
            ),
            array('%s', '%s', '%d')
        );
    }

    public static function info($message, $context = array()) {
        self::log($message, self::LEVEL_INFO, $context);
    }

    public static function warning($message, $context = array()) {
        self::log($message, self::LEVEL_WARNING, $context);
    }

    public static function error($message, $context = array()) {
        self::log($message, self::LEVEL_ERROR, $context);
    }

    public static function debug($message, $context = array()) {
        self::log($message, self::LEVEL_DEBUG, $context);
    }
}
