<?php
namespace LinkCPR;

class Activator {

    public static function activate() {
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-database.php';
        Database::create_tables();

        $defaults = array(
            'link_cpr_auto_scan'            => 'weekly',
            'link_cpr_enable_archive_fix'   => 1,
            'link_cpr_enable_internal_fix'  => 1,
            'link_cpr_enable_remove_fix'    => 0,
            'link_cpr_email_reports'        => 1,
            'link_cpr_report_email'         => get_option('admin_email'),
            'link_cpr_batch_size'           => 10,
            'link_cpr_request_timeout'      => 15,
            'link_cpr_post_types'           => array('post', 'page'),
            'link_cpr_scan_images'          => 0,
            'link_cpr_exclude_urls'         => '',
            'link_cpr_rate_limit_delay'     => 0,
            'link_cpr_slack_webhook'        => '',
        );

        foreach ($defaults as $key => $value) {
            if (false === get_option($key)) {
                update_option($key, $value);
            }
        }

        if (!wp_next_scheduled('link_cpr_scheduled_scan')) {
            wp_schedule_event(time(), 'daily', 'link_cpr_scheduled_scan');
        }

        Logger::info('Link CPR activated and database tables created.');
    }
}
