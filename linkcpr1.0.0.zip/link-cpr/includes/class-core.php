<?php
namespace LinkCPR;

class Core {

    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function run() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_cron_hooks();
        $this->define_content_hooks();
        $this->check_system_health();
        add_action('admin_init', array('LinkCPR\\Database', 'maybe_upgrade'));
    }

    private function load_dependencies() {
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-database.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-logger.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-export.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-health-check.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-scanner.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-healer.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-scheduler.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-reports.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-settings.php';
        require_once LINK_CPR_PLUGIN_DIR . 'includes/class-admin.php';
    }

    private function set_locale() {
        add_action('plugins_loaded', function() {
            load_plugin_textdomain('link-cpr', false, dirname(LINK_CPR_PLUGIN_BASENAME) . '/languages/');
        });
    }

    private function define_admin_hooks() {
        $admin = new Admin();
        $admin->init();
    }

    private function define_cron_hooks() {
        add_action('link_cpr_scheduled_scan', array(new Scheduler(), 'run_scheduled_scan'));
        add_action('link_cpr_process_batch', array(new Scheduler(), 'process_batch_queue'));
    }

    private function define_content_hooks() {
        add_action('save_post', array($this, 'scan_on_save'), 20, 3);
    }

    public function scan_on_save($post_id, $post, $update) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        if ($post->post_status !== 'publish') {
            return;
        }

        $post_types = get_option('link_cpr_post_types', array('post', 'page'));
        if (! in_array($post->post_type, (array) $post_types, true)) {
            return;
        }

        $scanner = new Scanner();
        $scanner->scan_post($post_id);
    }

    private function check_system_health() {
        $issues = HealthCheck::run();
        if (!empty($issues)) {
            foreach ($issues as $issue) {
                Logger::warning($issue);
            }
            add_action('admin_notices', function() use ($issues) {
                echo '<div class="notice notice-warning is-dismissible"><p><strong>Link CPR:</strong> ' . esc_html(implode(' ', $issues)) . '</p></div>';
            });
        }
    }
}
