<?php
namespace LinkCPR;

class Scheduler {

    public function run_scheduled_scan() {
        $scanner = new Scanner();
        $scanner->queue_all_posts();

        if (! wp_next_scheduled('link_cpr_process_batch')) {
            wp_schedule_single_event(time(), 'link_cpr_process_batch');
        }

        Logger::info('Scheduled scan started.');
    }

    public function process_batch_queue() {
        global $wpdb;
        $table_queue = $wpdb->prefix . 'link_cpr_queue';
        $batch_size  = (int) get_option('link_cpr_batch_size', 10);

        $items = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_queue WHERE status = 'pending' LIMIT %d",
                $batch_size
            ),
            ARRAY_A
        );

        if (empty($items)) {
            Logger::info('Batch queue empty. Scan complete.');
            $this->maybe_send_report();
            return;
        }

        $scanner = new Scanner();

        foreach ($items as $item) {
            $scanner->scan_post((int) $item['post_id']);
            $wpdb->update(
                $table_queue,
                array(
                    'status'       => 'completed',
                    'processed_at' => current_time('mysql'),
                ),
                array('id' => $item['id']),
                array('%s', '%s'),
                array('%d')
            );
        }

        wp_schedule_single_event(time() + 5, 'link_cpr_process_batch');
    }

    private function maybe_send_report() {
        $reports = new Reports();

        if (get_option('link_cpr_email_reports', 0)) {
            $reports->send_email_report();
        }

        $reports->send_slack_notification();
    }
}
