<?php
/**
 * Plugin Name: Link CPR - Broken Link Auto-Healer
 * Plugin URI: https://example.com/link-cpr
 * Description: Professional broken link scanner and auto-healer using Wayback Machine & intelligent internal linking. Features a modern dashboard, scheduled scanning, and detailed reports.
 * Version: 1.0.0
 * Author: Link CPR
 * Author URI: https://example.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: link-cpr
 * Domain Path: /languages
 */

if (!defined('WPINC')) {
    die;
}

define('LINK_CPR_VERSION', '1.0.0');
define('LINK_CPR_PLUGIN_NAME', 'Link CPR');
define('LINK_CPR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LINK_CPR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('LINK_CPR_PLUGIN_BASENAME', plugin_basename(__FILE__));

function activate_link_cpr() {
    require_once LINK_CPR_PLUGIN_DIR . 'includes/class-activator.php';
    LinkCPR\Activator::activate();
}

function deactivate_link_cpr() {
    require_once LINK_CPR_PLUGIN_DIR . 'includes/class-deactivator.php';
    LinkCPR\Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_link_cpr');
register_deactivation_hook(__FILE__, 'deactivate_link_cpr');

require LINK_CPR_PLUGIN_DIR . 'includes/class-core.php';

function run_link_cpr() {
    $plugin = new LinkCPR\Core();
    $plugin->run();
}
run_link_cpr();
