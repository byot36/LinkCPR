(function($) {
    'use strict';

    var currentPage = 1;
    var progressTimer = null;

    $(document).ready(function() {
        if ($('.lcpr-stats-grid').length) {
            loadStats();
        }

        renderActivityChart();

        $(document).on('keyup', '#lcpr-search-links', function() {
            var value = $(this).val().toLowerCase();
            $('#lcpr-broken-links-body tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
            });
        });

        $('#lcpr-select-all').on('change', function() {
            $('.lcpr-row-select').prop('checked', $(this).prop('checked'));
        });

        $('#lcpr-apply-filters').on('click', function(e) {
            e.preventDefault();
            var params = new URLSearchParams(window.location.search);
            params.set('post_type', $('#lcpr-filter-post-type').val() || '');
            params.set('status_code', $('#lcpr-filter-status-code').val() || '');
            params.set('date_from', $('#lcpr-filter-date-from').val() || '');
            params.set('date_to', $('#lcpr-filter-date-to').val() || '');
            params.set('lcpr_page', 1);
            window.location.search = params.toString();
        });

        $('#lcpr-start-scan').on('click', function(e) {
            e.preventDefault();
            var $btn = $(this);
            if ($btn.prop('disabled')) return;

            $btn.prop('disabled', true).find('.lcpr-text').text(linkCPR.strings.scanStarted || 'Scanning...');
            $btn.find('.lcpr-spinner').show();

            $.post(linkCPR.ajaxUrl, {
                action: 'link_cpr_start_scan',
                nonce: linkCPR.nonce
            }, function(response) {
                if (response.success) {
                    showToast(response.data.message, 'success');
                    startProgressPolling();
                } else {
                    showToast(response.data || linkCPR.strings.error, 'error');
                }
            }).fail(function() {
                showToast(linkCPR.strings.error, 'error');
            }).always(function() {
                $btn.prop('disabled', false).find('.lcpr-text').text('Start New Scan');
                $btn.find('.lcpr-spinner').hide();
            });
        });

        $('#lcpr-refresh-stats').on('click', function(e) {
            e.preventDefault();
            var $icon = $(this).find('.dashicons');
            if ($icon.length) {
                $icon.addClass('spin');
            }
            loadStats();
            setTimeout(function() {
                if ($icon.length) $icon.removeClass('spin');
            }, 800);
        });

        $(document).on('click', '.lcpr-fix-btn', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var linkId = $btn.data('id');
            var method = $btn.data('method');

            if (!confirm(linkCPR.strings.fixConfirm)) return;

            $btn.prop('disabled', true).text('Fixing...');

            $.post(linkCPR.ajaxUrl, {
                action: 'link_cpr_fix_link',
                nonce: linkCPR.nonce,
                link_id: linkId,
                method: method
            }, function(response) {
                if (response.success) {
                    showToast(response.data.message, 'success');
                    $btn.closest('tr').fadeOut(300, function() {
                        $(this).remove();
                        loadStats();
                    });
                } else {
                    showToast(response.data || linkCPR.strings.error, 'error');
                    $btn.prop('disabled', false).text(capitalizeFirst(method));
                }
            }).fail(function() {
                showToast(linkCPR.strings.error, 'error');
                $btn.prop('disabled', false).text(capitalizeFirst(method));
            });
        });

        $(document).on('click', '.lcpr-fix-manual-btn', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var linkId = $btn.data('id');
            var url = window.prompt('Enter the replacement URL:');

            if (!url) return;

            $.post(linkCPR.ajaxUrl, {
                action: 'link_cpr_fix_link',
                nonce: linkCPR.nonce,
                link_id: linkId,
                method: 'manual',
                manual_url: url
            }, function(response) {
                if (response.success) {
                    showToast(response.data.message, 'success');
                    $btn.closest('tr').fadeOut(300, function() {
                        $(this).remove();
                        loadStats();
                    });
                } else {
                    showToast(response.data || linkCPR.strings.error, 'error');
                }
            }).fail(function() {
                showToast(linkCPR.strings.error, 'error');
            });
        });

        $('#lcpr-bulk-fix').on('click', function(e) {
            e.preventDefault();
            var ids = $('.lcpr-row-select:checked').map(function() {
                return $(this).val();
            }).get();

            if (!ids.length) {
                showToast('Select at least one link.', 'error');
                return;
            }

            if (!confirm(linkCPR.strings.fixConfirm)) return;

            var method = $('#lcpr-bulk-method').val();
            var $btn = $(this);
            $btn.prop('disabled', true);

            $.post(linkCPR.ajaxUrl, {
                action: 'link_cpr_bulk_fix',
                nonce: linkCPR.nonce,
                link_ids: ids,
                method: method
            }, function(response) {
                if (response.success) {
                    showToast(response.data.message, 'success');
                    setTimeout(function() { location.reload(); }, 1500);
                } else {
                    showToast(response.data || linkCPR.strings.error, 'error');
                }
            }).fail(function() {
                showToast(linkCPR.strings.error, 'error');
            }).always(function() {
                $btn.prop('disabled', false);
            });
        });

        $('#lcpr-export-csv').on('click', function(e) {
            e.preventDefault();
            window.location.href = linkCPR.ajaxUrl + '?action=link_cpr_export_csv&nonce=' + encodeURIComponent(linkCPR.nonce);
        });
    });

    function startProgressPolling() {
        var $progress = $('#lcpr-scan-progress');
        if (!$progress.length) return;

        $progress.show();

        if (progressTimer) {
            clearInterval(progressTimer);
        }

        progressTimer = setInterval(function() {
            $.post(linkCPR.ajaxUrl, {
                action: 'link_cpr_scan_progress',
                nonce: linkCPR.nonce
            }, function(response) {
                if (!response.success) return;

                var data = response.data;
                var pct = data.total > 0 ? Math.round((data.completed / data.total) * 100) : 0;

                $('#lcpr-progress-text').text(data.completed + ' / ' + data.total);
                $('#lcpr-progress-bar').css('width', pct + '%');

                if (data.total > 0 && data.completed >= data.total) {
                    clearInterval(progressTimer);
                    setTimeout(function() {
                        $progress.hide();
                        location.reload();
                    }, 1000);
                }
            });
        }, 3000);
    }

    function renderActivityChart() {
        var canvas = document.getElementById('lcpr-activity-chart');
        if (!canvas || typeof Chart === 'undefined') return;

        var labels = JSON.parse(canvas.getAttribute('data-labels') || '[]');
        var values = JSON.parse(canvas.getAttribute('data-values') || '[]');

        new Chart(canvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Fixes',
                    data: values,
                    backgroundColor: '#4f46e5'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });
    }

    function loadStats() {
        $.post(linkCPR.ajaxUrl, {
            action: 'link_cpr_get_stats',
            nonce: linkCPR.nonce
        }, function(response) {
            if (response.success) {
                var stats = response.data;
                animateValue('#stat-total', parseInt($('#stat-total').text()) || 0, stats.total, 600);
                animateValue('#stat-broken', parseInt($('#stat-broken').text()) || 0, stats.broken, 600);
                animateValue('#stat-fixed', parseInt($('#stat-fixed').text()) || 0, stats.fixed, 600);
                animateValue('#stat-pending', parseInt($('#stat-pending').text()) || 0, stats.pending, 600);
            }
        });
    }

    function animateValue(selector, start, end, duration) {
        if (start === end) return;
        var range = end - start;
        var current = start;
        var increment = end > start ? 1 : -1;
        var stepTime = Math.abs(Math.floor(duration / range));
        if (stepTime < 10) stepTime = 10;
        if (stepTime > 200) stepTime = 50;
        var obj = $(selector);
        var timer = setInterval(function() {
            current += increment;
            obj.text(current);
            if (current === end) {
                clearInterval(timer);
            }
        }, stepTime);
    }

    function showToast(message, type) {
        type = type || 'success';
        var $toast = $('<div class="lcpr-toast ' + type + '">' + message + '</div>');
        $('body').append($toast);
        setTimeout(function() {
            $toast.addClass('show');
        }, 10);
        setTimeout(function() {
            $toast.removeClass('show');
            setTimeout(function() {
                $toast.remove();
            }, 300);
        }, 3000);
    }

    function capitalizeFirst(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

})(jQuery);
