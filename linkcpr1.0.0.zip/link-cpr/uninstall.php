<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

require_once __DIR__ . '/includes/class-uninstaller.php';

LinkCPR\Uninstaller::uninstall();
