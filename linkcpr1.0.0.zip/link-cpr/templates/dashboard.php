<?php
if (!defined('ABSPATH')) exit;

$stats = \LinkCPR\Database::get_stats();
$health = \LinkCPR\HealthCheck::run();
?>
<div class="wrap link-cpr-wrap">
    <div class="link-cpr-header">
        <h1><?php _e('Link CPR Dashboard', 'link-cpr'); ?></h1>
        <p><?php _e('Monitor, scan and automatically heal broken links across your entire website.', 'link-cpr'); ?></p>
    </div>

    <?php if (!empty($health)) : ?>
        <div class="notice notice-warning">
            <?php foreach ($health as $issue) : ?>
                <p><?php echo esc_html($issue); ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="lcpr-action-bar">
        <div style="display:flex; gap:12px;">
            <button id="lcpr-start-scan" class="lcpr-btn lcpr-btn-primary">
                <span class="lcpr-spinner"></span>
                <span class="lcpr-text"><?php _e('Start New Scan', 'link-cpr'); ?></span>
            </button>
            <button id="lcpr-refresh-stats" class="lcpr-btn lcpr-btn-secondary">
                <span class="dashicons dashicons-update" style="margin-right:4px;"></span>
                <?php _e('Refresh Stats', 'link-cpr'); ?>
            </button>
        </div>
        <div style="color: var(--lcpr-text-muted); font-size: 0.95rem;">
            <?php
            $next = wp_next_scheduled('link_cpr_scheduled_scan');
            printf(
                __('Next scheduled scan: %s', 'link-cpr'),
                $next ? human_time_diff($next, time()) . ' ' . __('from now', 'link-cpr') : __('Not scheduled', 'link-cpr')
            );
            ?>
        </div>
    </div>

    <div class="lcpr-stats-grid">
        <div class="lcpr-stat-card total">
            <div class="lcpr-icon">🔗</div>
            <h3><?php _e('Total Links Checked', 'link-cpr'); ?></h3>
            <div class="lcpr-value" id="stat-total"><?php echo intval($stats['total']); ?></div>
            <div class="lcpr-delta"><?php _e('All time scanned', 'link-cpr'); ?></div>
        </div>
        <div class="lcpr-stat-card broken">
            <div class="lcpr-icon">⚠️</div>
            <h3><?php _e('Broken Found', 'link-cpr'); ?></h3>
            <div class="lcpr-value" id="stat-broken"><?php echo intval($stats['broken']); ?></div>
            <div class="lcpr-delta"><?php _e('Require attention', 'link-cpr'); ?></div>
        </div>
        <div class="lcpr-stat-card fixed">
            <div class="lcpr-icon">✅</div>
            <h3><?php _e('Fixed', 'link-cpr'); ?></h3>
            <div class="lcpr-value" id="stat-fixed"><?php echo intval($stats['fixed']); ?></div>
            <div class="lcpr-delta"><?php _e('Successfully healed', 'link-cpr'); ?></div>
        </div>
        <div class="lcpr-stat-card pending">
            <div class="lcpr-icon">🩹</div>
            <h3><?php _e('Pending Fixes', 'link-cpr'); ?></h3>
            <div class="lcpr-value" id="stat-pending"><?php echo intval($stats['pending']); ?></div>
            <div class="lcpr-delta"><?php _e('Awaiting action', 'link-cpr'); ?></div>
        </div>
    </div>

    <div class="lcpr-table-wrap" style="padding: 24px;">
        <h2 style="margin-top:0; margin-bottom:20px; font-size: 1.25rem;"><?php _e('Quick Actions', 'link-cpr'); ?></h2>
        <p style="color: var(--lcpr-text-muted); margin-bottom: 20px;">
            <?php _e('Use the Scan Results page to view and fix broken links individually or in bulk.', 'link-cpr'); ?>
        </p>
        <a href="<?php echo esc_url(admin_url('admin.php?page=link-cpr-results')); ?>" class="lcpr-btn lcpr-btn-primary" style="margin-right: 8px;">
            <?php _e('View All Broken Links', 'link-cpr'); ?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=link-cpr-settings')); ?>" class="lcpr-btn lcpr-btn-secondary">
            <?php _e('Open Settings', 'link-cpr'); ?>
        </a>
    </div>
</div>
