<?php
if (!defined('ABSPATH')) exit;

$reports_obj = new \LinkCPR\Reports();
$chart_data = $reports_obj->generate_chart_data(7);

global $wpdb;
$table_logs = $wpdb->prefix . 'link_cpr_logs';
$recent_logs = $wpdb->get_results("SELECT * FROM $table_logs ORDER BY created_at DESC LIMIT 20", ARRAY_A);
?>
<div class="wrap link-cpr-wrap">
    <div class="link-cpr-header">
        <h1><?php _e('Reports & Logs', 'link-cpr'); ?></h1>
        <p><?php _e('Track performance and historical fixes over time.', 'link-cpr'); ?></p>
    </div>

    <div class="lcpr-stats-grid" style="margin-bottom: 30px;">
        <div class="lcpr-stat-card">
            <div class="lcpr-icon">📊</div>
            <h3><?php _e('Last 7 Days Activity', 'link-cpr'); ?></h3>
            <div style="margin-top: 16px;">
                <canvas id="lcpr-activity-chart" height="160"
                    data-labels="<?php echo esc_attr(wp_json_encode(wp_list_pluck($chart_data, 'date'))); ?>"
                    data-values="<?php echo esc_attr(wp_json_encode(wp_list_pluck($chart_data, 'count'))); ?>"></canvas>
            </div>
        </div>
        <div class="lcpr-stat-card">
            <div class="lcpr-icon">🔧</div>
            <h3><?php _e('System Health', 'link-cpr'); ?></h3>
            <ul style="list-style:none; padding:0; margin-top:16px; color: var(--lcpr-text-muted);">
                <li style="margin-bottom:8px;">✓ <?php _e('Database Tables: Connected', 'link-cpr'); ?></li>
                <li style="margin-bottom:8px;">✓ <?php _e('WP Cron:', 'link-cpr'); ?> <?php echo wp_next_scheduled('link_cpr_scheduled_scan') ? __('Active', 'link-cpr') : __('Inactive', 'link-cpr'); ?></li>
                <li style="margin-bottom:8px;">✓ <?php _e('PHP DOMDocument:', 'link-cpr'); ?> <?php echo class_exists('DOMDocument') ? __('Available', 'link-cpr') : __('Missing', 'link-cpr'); ?></li>
                <li>✓ <?php _e('WordPress Version:', 'link-cpr'); ?> <?php echo esc_html(get_bloginfo('version')); ?></li>
            </ul>
        </div>
    </div>

    <div class="lcpr-action-bar" style="margin-bottom: 20px;">
        <button id="lcpr-export-csv" class="lcpr-btn lcpr-btn-secondary"><?php _e('Download Full CSV Export', 'link-cpr'); ?></button>
    </div>

    <div class="lcpr-table-wrap">
        <h2 style="padding: 24px 24px 0; margin:0;"><?php _e('Recent Logs', 'link-cpr'); ?></h2>
        <table>
            <thead>
                <tr>
                    <th><?php _e('Action', 'link-cpr'); ?></th>
                    <th><?php _e('Details', 'link-cpr'); ?></th>
                    <th><?php _e('User', 'link-cpr'); ?></th>
                    <th><?php _e('Date', 'link-cpr'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_logs as $log) :
                    $user = $log['performed_by'] ? get_userdata($log['performed_by']) : false;
                ?>
                <tr>
                    <td><span class="lcpr-badge lcpr-badge-fixed"><?php echo esc_html($log['action']); ?></span></td>
                    <td><?php echo esc_html($log['details']); ?></td>
                    <td><?php echo $user ? esc_html($user->display_name) : __('System', 'link-cpr'); ?></td>
                    <td><?php echo esc_html(human_time_diff(strtotime($log['created_at']), time()) . ' ' . __('ago', 'link-cpr')); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($recent_logs)) : ?>
                    <tr><td colspan="4" style="text-align:center; padding: 30px;"><?php _e('No logs yet.', 'link-cpr'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
