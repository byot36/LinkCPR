<?php
if (!defined('ABSPATH')) exit;

$current_page = isset($_GET['lcpr_page']) ? max(1, intval($_GET['lcpr_page'])) : 1;
$per_page     = 20;

$filters = array(
    'post_type'   => isset($_GET['post_type']) ? sanitize_text_field(wp_unslash($_GET['post_type'])) : '',
    'status_code' => isset($_GET['status_code']) ? sanitize_text_field(wp_unslash($_GET['status_code'])) : '',
    'date_from'   => isset($_GET['date_from']) ? sanitize_text_field(wp_unslash($_GET['date_from'])) : '',
    'date_to'     => isset($_GET['date_to']) ? sanitize_text_field(wp_unslash($_GET['date_to'])) : '',
);

$scanner = new \LinkCPR\Scanner();
$result  = $scanner->get_broken_links($per_page, ($current_page - 1) * $per_page, $filters);
$broken  = $result['items'];
$total_pages = max(1, ceil($result['total'] / $per_page));

$post_types = get_post_types(array('public' => true), 'objects');
?>
<div class="wrap link-cpr-wrap">
    <div class="link-cpr-header">
        <h1><?php _e('Scan Results', 'link-cpr'); ?></h1>
        <p><?php _e('Review broken links and heal them with one click.', 'link-cpr'); ?></p>
    </div>

    <div class="lcpr-action-bar">
        <div style="display:flex; gap:12px; align-items:center;">
            <button id="lcpr-start-scan" class="lcpr-btn lcpr-btn-primary">
                <span class="lcpr-spinner"></span>
                <span class="lcpr-text"><?php _e('Re-scan Now', 'link-cpr'); ?></span>
            </button>
            <button id="lcpr-export-csv" class="lcpr-btn lcpr-btn-secondary">
                <?php _e('Export CSV', 'link-cpr'); ?>
            </button>
        </div>
        <div>
            <input type="text" id="lcpr-search-links" class="lcpr-search-input" placeholder="<?php _e('Search links...', 'link-cpr'); ?>" />
        </div>
    </div>

    <div id="lcpr-scan-progress" style="display:none; margin-bottom:20px;">
        <div style="background:var(--lcpr-card-bg); border-radius:var(--lcpr-radius); padding:16px 24px; border:1px solid var(--lcpr-border);">
            <div style="display:flex; justify-content:space-between; margin-bottom:8px; font-size:0.9rem;">
                <span><?php _e('Scanning posts...', 'link-cpr'); ?></span>
                <span id="lcpr-progress-text">0 / 0</span>
            </div>
            <div style="background:var(--lcpr-bg); border-radius:4px; height:10px; overflow:hidden;">
                <div id="lcpr-progress-bar" style="width:0%; background:linear-gradient(90deg, var(--lcpr-primary), var(--lcpr-secondary)); height:100%;"></div>
            </div>
        </div>
    </div>

    <div class="lcpr-action-bar" style="flex-wrap: wrap; gap: 12px;">
        <select id="lcpr-filter-post-type">
            <option value=""><?php _e('All Post Types', 'link-cpr'); ?></option>
            <?php foreach ($post_types as $pt) : ?>
                <option value="<?php echo esc_attr($pt->name); ?>" <?php selected($filters['post_type'], $pt->name); ?>><?php echo esc_html($pt->labels->singular_name); ?></option>
            <?php endforeach; ?>
        </select>
        <select id="lcpr-filter-status-code">
            <option value=""><?php _e('All Status Codes', 'link-cpr'); ?></option>
            <option value="404" <?php selected($filters['status_code'], '404'); ?>>404</option>
            <option value="0" <?php selected($filters['status_code'], '0'); ?>><?php _e('Connection Failed', 'link-cpr'); ?></option>
            <option value="500" <?php selected($filters['status_code'], '500'); ?>>500</option>
            <option value="403" <?php selected($filters['status_code'], '403'); ?>>403</option>
        </select>
        <input type="date" id="lcpr-filter-date-from" value="<?php echo esc_attr($filters['date_from']); ?>" />
        <input type="date" id="lcpr-filter-date-to" value="<?php echo esc_attr($filters['date_to']); ?>" />
        <button id="lcpr-apply-filters" class="lcpr-btn lcpr-btn-secondary"><?php _e('Apply Filters', 'link-cpr'); ?></button>

        <select id="lcpr-bulk-method" style="margin-left:auto;">
            <option value="archive"><?php _e('Archive.org', 'link-cpr'); ?></option>
            <option value="internal"><?php _e('Internal Link', 'link-cpr'); ?></option>
            <option value="remove"><?php _e('Remove Link', 'link-cpr'); ?></option>
        </select>
        <button id="lcpr-bulk-fix" class="lcpr-btn lcpr-btn-primary"><?php _e('Fix Selected', 'link-cpr'); ?></button>
    </div>

    <div class="lcpr-table-wrap">
        <table>
            <thead>
                <tr>
                    <th style="width:24px;"><input type="checkbox" id="lcpr-select-all" /></th>
                    <th><?php _e('URL', 'link-cpr'); ?></th>
                    <th><?php _e('Link Text', 'link-cpr'); ?></th>
                    <th><?php _e('Status', 'link-cpr'); ?></th>
                    <th><?php _e('Post', 'link-cpr'); ?></th>
                    <th><?php _e('Suggested Fix', 'link-cpr'); ?></th>
                    <th><?php _e('Actions', 'link-cpr'); ?></th>
                </tr>
            </thead>
            <tbody id="lcpr-broken-links-body">
                <?php if (!empty($broken)) : ?>
                    <?php foreach ($broken as $row) :
                        $post = get_post($row['post_id']);
                        $archive = !empty($row['archive_url']);
                        $internal = !empty($row['internal_suggestion']);
                    ?>
                    <tr>
                        <td><input type="checkbox" class="lcpr-row-select" value="<?php echo intval($row['id']); ?>" /></td>
                        <td>
                            <a href="<?php echo esc_url($row['url']); ?>" target="_blank" rel="noopener" style="color: var(--lcpr-primary); font-weight: 600;">
                                <?php echo esc_html(substr($row['url'], 0, 60)) . (strlen($row['url']) > 60 ? '...' : ''); ?>
                            </a>
                            <?php if (!empty($row['link_type']) && $row['link_type'] === 'image') : ?>
                                <span class="lcpr-badge lcpr-badge-removed" style="margin-left:6px;">IMG</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($row['link_text'] ?: '-'); ?></td>
                        <td><span class="lcpr-badge lcpr-badge-broken"><?php echo esc_html($row['status_code'] ?: 'ERR'); ?></span></td>
                        <td>
                            <?php if ($post) : ?>
                                <a href="<?php echo esc_url(get_edit_post_link($post->ID)); ?>" target="_blank"><?php echo esc_html($post->post_title); ?></a>
                            <?php else : ?>
                                <em><?php _e('Deleted', 'link-cpr'); ?></em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($archive) : ?>
                                <div style="font-size: 0.85rem; color: var(--lcpr-success); margin-bottom: 4px;">✓ Archive.org</div>
                            <?php endif; ?>
                            <?php if ($internal) : ?>
                                <div style="font-size: 0.85rem; color: var(--lcpr-secondary);">✓ Internal Link</div>
                            <?php endif; ?>
                            <?php if (!$archive && !$internal) : ?>
                                <span style="color: var(--lcpr-text-muted); font-size: 0.85rem;"><?php _e('None available', 'link-cpr'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($archive) : ?>
                                <button class="lcpr-btn lcpr-btn-primary lcpr-fix-btn" style="padding: 6px 12px; font-size: 0.85rem;" data-id="<?php echo intval($row['id']); ?>" data-method="archive"><?php _e('Fix Archive', 'link-cpr'); ?></button>
                            <?php endif; ?>
                            <?php if ($internal) : ?>
                                <button class="lcpr-btn lcpr-btn-secondary lcpr-fix-btn" style="padding: 6px 12px; font-size: 0.85rem;" data-id="<?php echo intval($row['id']); ?>" data-method="internal"><?php _e('Fix Internal', 'link-cpr'); ?></button>
                            <?php endif; ?>
                            <button class="lcpr-btn lcpr-fix-btn" style="padding: 6px 12px; font-size: 0.85rem; background: #f3f4f6; color: #4b5563;" data-id="<?php echo intval($row['id']); ?>" data-method="remove"><?php _e('Remove', 'link-cpr'); ?></button>
                            <button class="lcpr-btn lcpr-fix-manual-btn" style="padding: 6px 12px; font-size: 0.85rem; background: #f3f4f6; color: #4b5563;" data-id="<?php echo intval($row['id']); ?>"><?php _e('Manual URL', 'link-cpr'); ?></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7" style="text-align:center; padding: 40px; color: var(--lcpr-text-muted);">
                            <?php _e('No broken links found. Great job!', 'link-cpr'); ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($total_pages > 1) : ?>
    <div id="lcpr-pagination" style="display:flex; justify-content:center; gap:8px; margin-top:16px;">
        <?php for ($i = 1; $i <= $total_pages; $i++) :
            $url = add_query_arg(array_merge($filters, array('lcpr_page' => $i)));
        ?>
            <a href="<?php echo esc_url($url); ?>" class="lcpr-btn <?php echo ($i === $current_page) ? 'lcpr-btn-primary' : 'lcpr-btn-secondary'; ?>" style="padding:6px 12px;"><?php echo intval($i); ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>
