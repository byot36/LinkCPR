<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap link-cpr-wrap">
    <div class="link-cpr-header">
        <h1><?php _e('Settings', 'link-cpr'); ?></h1>
        <p><?php _e('Configure scanning behaviour, auto-fix rules and notifications.', 'link-cpr'); ?></p>
    </div>

    <div class="lcpr-settings-form">
        <form method="post" action="options.php">
            <?php
            settings_fields('link_cpr_settings_group');
            do_settings_sections('link-cpr-settings');
            submit_button(__('Save Settings', 'link-cpr'), 'lcpr-btn lcpr-btn-primary');
            ?>
        </form>
    </div>
</div>
